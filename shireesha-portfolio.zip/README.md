# 🌐 Dasari Shireesha – Portfolio Website

A clean and elegant personal portfolio website built using **HTML5** and **CSS3**.

---

## 🚀 Live Preview
🔗 [https://Shire-esha9573.github.io/shireesha-portfolio/](https://Shire-esha9573.github.io/shireesha-portfolio/)

---

## 🧰 Features
- Simple, professional, and responsive design  
- Smooth fade-in animations  
- Projects, Skills, Certifications, and Contact sections  
- Fully deployable on **GitHub Pages**

---

## ⚙️ How to Use

1. **Clone the repository**
   ```bash
   git clone https://github.com/Shire-esha9573/shireesha-portfolio.git
   ```
2. **Open in browser**
   Just double-click `index.html`.

3. **To deploy on GitHub Pages**
   - Go to repository → **Settings → Pages**
   - Set branch = `main`, folder = `/ (root)`
   - Click **Save**

---

## 🪪 Author
**Dasari Shireesha**  
📧 [shireeshadasari348@gmail.com](mailto:shireeshadasari348@gmail.com)  
💻 [GitHub](https://github.com/Shire-esha9573) | 🔗 [LinkedIn](https://linkedin.com/in/dasari-shireesha-87a846354)
